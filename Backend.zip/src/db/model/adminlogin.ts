import { BaseModel } from "./baseModel";

export class AdminLogin extends BaseModel {
  email: string;
  password: string;
}
